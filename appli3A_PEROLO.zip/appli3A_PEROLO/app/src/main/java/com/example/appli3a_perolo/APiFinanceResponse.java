package com.example.appli3a_perolo;
import java.util.List;

public class APiFinanceResponse {
    private List<Symbol> symbolsList;

    public List<Symbol> getSymbolsList() {
        return symbolsList;
    }
}
