package com.example.appli3a_perolo;

public class Constants {
    static String KEY_SYMBOLS_LIST = "jsonSymbolsList";
}
